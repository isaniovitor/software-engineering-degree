public interface Predicado<T> {
	boolean aplicarA(T type, Object criteria);
}
