package classes;

public class Garcom {

    public Garcom() {
    }
    
    public void addPedidoCozinha(){
        System.out.println("Pedidos serão add a fila, com licença!");
    }

    public void avisoPedidoPronto(){
		System.out.println("Pedidos solicitados prontos, aqui estão!");
    }
}