public class Cachorro extends Animal{
    public Cachorro(String aNome){
        super(aNome);
        this.numPatas = 4;
    }
}
