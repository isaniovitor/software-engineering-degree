
public class Cacique extends Indio{
	public Cacique(String nome) { 
		super(nome); 
	} 
}
