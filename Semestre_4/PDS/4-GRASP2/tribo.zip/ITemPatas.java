public interface ITemPatas{
    public int getNumPatas();
}