public class Pato extends Animal{
    public Pato(String aNome){
        super(aNome);
        this.numPatas = 2;
    }
}